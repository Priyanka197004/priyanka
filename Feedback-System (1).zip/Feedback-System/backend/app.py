"""
=============================================================
 FEEDBACK MANAGEMENT SYSTEM — BACKEND (Flask)
=============================================================
 Provides a single REST endpoint that receives feedback data
 from the frontend and persists it inside a local JSON file
 (feedback.json), acting as a lightweight file-based database.
=============================================================
"""

import json
import os
import re
from datetime import datetime

from flask import Flask, request, jsonify
from flask_cors import CORS

# -------------------------------------------------------------------
# App configuration
# -------------------------------------------------------------------
app = Flask(__name__)
CORS(app)  # Allow cross-origin requests from the frontend (different port/origin)

# Path to the JSON "database" file, kept alongside this script
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "feedback.json")

EMAIL_REGEX = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


# -------------------------------------------------------------------
# Helper functions
# -------------------------------------------------------------------
def load_feedback():
    """Read all existing feedback entries from feedback.json."""
    if not os.path.exists(DATA_FILE):
        return []

    try:
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            content = file.read().strip()
            return json.loads(content) if content else []
    except (json.JSONDecodeError, IOError):
        # If the file is corrupted or unreadable, fail safe with an empty list
        return []


def save_feedback(entries):
    """Write the full list of feedback entries back to feedback.json."""
    with open(DATA_FILE, "w", encoding="utf-8") as file:
        json.dump(entries, file, indent=2, ensure_ascii=False)


def validate_payload(data):
    """
    Validate incoming feedback data.
    Returns a list of error messages (empty list means data is valid).
    """
    errors = []

    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip()
    rating = data.get("rating")
    feedback = (data.get("feedback") or "").strip()

    if not name:
        errors.append("Name is required.")
    elif len(name) < 3:
        errors.append("Name must be at least 3 characters.")

    if not email:
        errors.append("Email is required.")
    elif not EMAIL_REGEX.match(email):
        errors.append("A valid email address is required.")

    if rating is None or not isinstance(rating, (int, float)) or not (1 <= rating <= 5):
        errors.append("Rating must be between 1 and 5.")

    if not feedback:
        errors.append("Feedback is required.")
    elif len(feedback) < 20:
        errors.append("Feedback must be at least 20 characters.")

    return errors


# -------------------------------------------------------------------
# Routes
# -------------------------------------------------------------------
@app.route("/", methods=["GET"])
def index():
    """Simple health-check route."""
    return jsonify({"status": "ok", "message": "Feedback Management System API is running."})


@app.route("/submit-feedback", methods=["POST"])
def submit_feedback():
    """
    Accepts JSON feedback data, validates it, and appends it to feedback.json.

    Expected JSON body:
    {
        "name": "Priyanka",
        "email": "abc@gmail.com",
        "rating": 5,
        "feedback": "Excellent workshop!"
    }
    """
    data = request.get_json(silent=True)

    if data is None:
        return jsonify({"status": "error", "message": "Invalid or missing JSON body."}), 400

    errors = validate_payload(data)
    if errors:
        return jsonify({"status": "error", "message": " ".join(errors)}), 400

    new_entry = {
        "name": data.get("name").strip(),
        "email": data.get("email").strip(),
        "rating": int(data.get("rating")),
        "feedback": data.get("feedback").strip(),
        "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
    }

    entries = load_feedback()
    entries.append(new_entry)
    save_feedback(entries)

    return jsonify({
        "status": "success",
        "message": "Feedback submitted successfully.",
        "data": new_entry,
    }), 201


@app.route("/feedback", methods=["GET"])
def get_all_feedback():
    """Optional utility route to view all stored feedback entries."""
    return jsonify(load_feedback()), 200


# -------------------------------------------------------------------
# Entry point
# -------------------------------------------------------------------
if __name__ == "__main__":
    # Ensure the data file exists before the server starts
    if not os.path.exists(DATA_FILE):
        save_feedback([])

    app.run(debug=True, host="127.0.0.1", port=5000)
