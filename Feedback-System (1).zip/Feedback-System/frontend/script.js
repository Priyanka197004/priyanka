/* =========================================================
   FEEDBACK MANAGEMENT SYSTEM — CLIENT SCRIPT
   Handles: star rating, validation, fetch submission, UI states
========================================================= */

// ---------- Configuration ----------
const API_URL = "http://127.0.0.1:5000/submit-feedback";

// ---------- Element references ----------
const form = document.getElementById("feedbackForm");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const feedbackInput = document.getElementById("feedback");
const ratingInput = document.getElementById("rating");

const nameError = document.getElementById("nameError");
const emailError = document.getElementById("emailError");
const ratingError = document.getElementById("ratingError");
const feedbackError = document.getElementById("feedbackError");

const stars = document.querySelectorAll(".star");
const submitBtn = document.getElementById("submitBtn");
const successMessage = document.getElementById("successMessage");
const submitAnotherBtn = document.getElementById("submitAnotherBtn");
const toast = document.getElementById("toast");

let currentRating = 0;

/* =========================================================
   STAR RATING INTERACTION
========================================================= */
stars.forEach((star) => {
  const value = parseInt(star.dataset.value, 10);

  // Click to select rating
  star.addEventListener("click", () => {
    currentRating = value;
    ratingInput.value = currentRating;
    updateStars(currentRating);
    ratingError.textContent = "";
  });

  // Hover preview effect
  star.addEventListener("mouseenter", () => {
    highlightStars(value);
  });

  star.addEventListener("mouseleave", () => {
    highlightStars(currentRating);
  });
});

function updateStars(rating) {
  highlightStars(rating);
}

function highlightStars(rating) {
  stars.forEach((star) => {
    const value = parseInt(star.dataset.value, 10);
    star.classList.toggle("active", value <= rating);
  });
}

/* =========================================================
   VALIDATION HELPERS
========================================================= */
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function setError(inputEl, errorEl, message) {
  errorEl.textContent = message;
  inputEl.classList.toggle("input-error", Boolean(message));
}

function validateForm() {
  let isValid = true;

  // Name validation — required, min 3 characters
  const nameValue = nameInput.value.trim();
  if (!nameValue) {
    setError(nameInput, nameError, "Name is required.");
    isValid = false;
  } else if (nameValue.length < 3) {
    setError(nameInput, nameError, "Name must be at least 3 characters.");
    isValid = false;
  } else {
    setError(nameInput, nameError, "");
  }

  // Email validation — required, valid format
  const emailValue = emailInput.value.trim();
  if (!emailValue) {
    setError(emailInput, emailError, "Email is required.");
    isValid = false;
  } else if (!isValidEmail(emailValue)) {
    setError(emailInput, emailError, "Please enter a valid email address.");
    isValid = false;
  } else {
    setError(emailInput, emailError, "");
  }

  // Rating validation — must be between 1 and 5
  if (currentRating < 1 || currentRating > 5) {
    ratingError.textContent = "Please select a rating.";
    isValid = false;
  } else {
    ratingError.textContent = "";
  }

  // Feedback validation — required, min 20 characters
  const feedbackValue = feedbackInput.value.trim();
  if (!feedbackValue) {
    setError(feedbackInput, feedbackError, "Feedback is required.");
    isValid = false;
  } else if (feedbackValue.length < 20) {
    setError(feedbackInput, feedbackError, "Feedback must be at least 20 characters.");
    isValid = false;
  } else {
    setError(feedbackInput, feedbackError, "");
  }

  return isValid;
}

/* =========================================================
   TOAST NOTIFICATION
========================================================= */
let toastTimeout;

function showToast(message, type = "error") {
  clearTimeout(toastTimeout);
  toast.textContent = message;
  toast.classList.remove("success");
  if (type === "success") {
    toast.classList.add("success");
  }
  toast.classList.add("show");

  toastTimeout = setTimeout(() => {
    toast.classList.remove("show");
  }, 3500);
}

/* =========================================================
   FORM SUBMISSION
========================================================= */
form.addEventListener("submit", async (event) => {
  event.preventDefault();

  if (!validateForm()) {
    showToast("Please fix the highlighted errors before submitting.", "error");
    return;
  }

  const payload = {
    name: nameInput.value.trim(),
    email: emailInput.value.trim(),
    rating: currentRating,
    feedback: feedbackInput.value.trim(),
  };

  setLoading(true);

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || "Something went wrong. Please try again.");
    }

    showToast("Feedback submitted successfully!", "success");
    showSuccessState();
    resetForm();
  } catch (error) {
    showToast(error.message || "Unable to reach the server. Please try again.", "error");
  } finally {
    setLoading(false);
  }
});

function setLoading(isLoading) {
  submitBtn.disabled = isLoading;
  submitBtn.classList.toggle("loading", isLoading);
}

function showSuccessState() {
  form.style.display = "none";
  successMessage.classList.add("show");
}

function resetForm() {
  form.reset();
  currentRating = 0;
  highlightStars(0);
  ratingInput.value = 0;

  // Clear any lingering error states
  [nameInput, emailInput, feedbackInput].forEach((el) => el.classList.remove("input-error"));
  nameError.textContent = "";
  emailError.textContent = "";
  ratingError.textContent = "";
  feedbackError.textContent = "";
}

/* =========================================================
   "SUBMIT ANOTHER RESPONSE" BUTTON
========================================================= */
submitAnotherBtn.addEventListener("click", () => {
  successMessage.classList.remove("show");
  form.style.display = "flex";
});
